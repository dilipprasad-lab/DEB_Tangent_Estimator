clear all; close all; clc;
R=3;
im=imread('im.png');
im_gray=rgb2gray(im);
ed=edge(im_gray,'canny');
ed=bwmorph(ed,'skel',Inf);
edges=bwboundaries(ed);
for e=1:length(edges)
    tangent{e}=tangent_Prasad(edges{e},(R+1):(length(edges{e})-R),R);
    tangent_degrees{e}=atan(tangent{e})*180/pi;
    figure;plot(tangent_degrees{e})
end