% Usage: [m,c]=tangent_Prasad(edge,pixel_no,R);
%
% Inputs:  
% edge - the edge is [y(:) x(:)] where x and y are the x and y
%           coordinates of the input edge
% pixel_no - indices of the pixel for which the tangents are to be computed
% R - control parameter of the tangent estimator proposed in [1] below
%             
% Output:
% m - slope of the tangent
% c - intercept of the tangent
%     
% This function computes the tangent at the specified pixels on the input
% edge
%
% Copyright (c) 2011 Dilip K. Prasad
% School of Computer Engineering
% Nanyang Technological University, Singapore
% http://www.ntu.edu.sg/
%
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software with restriction for its use for research purpose only, 
% subject to the following conditions:
%
% The above copyright notice and this permission notice shall be included in
% all copies or substantial portions of the Software.
%
% The Software is provided "as is", without warranty of any kind.
%
% Please cite the any of the following work if this program is used
% [1] Dilip K. Prasad, Raj K. Gupta and Maylor K.H. Leung, �An error 
%       bounded tangent estimator for digitized elliptic curves,� 16th IAPR 
%       International Conference on Discrete Geometry for Computer Imagery 
%       (DGCI 2011), Nancy, France, 6-8 April, 2011.
% [1] Dilip K. Prasad, Maylor K.H. Leung, Chai Quek, and Michael S. Brown, 
%      �DEB: Definite error bounded tangent estimator for digital curves,� IEEE Transactions on Image Processing, 2014.

function [m,c]=tangent_Prasad(edge,pixel_no,R)
m=[];c=[];
for point=(pixel_no(:)).'
    found_P1=false;
    dist=abs(sqrt((edge(:,1)-edge(point,1)).^2+(edge(:,2)-edge(point,2)).^2)-R);
    [useless,index_P1]=min(flipud(dist(point-R:point-1)));
    [useless,index_P2]=min(dist(point+1:point+R));
    m(end+1)=(edge(point-index_P1,1)-edge(point+index_P2,1))/(edge(point-index_P1,2)-edge(point+index_P2,2));
    if isinf(m(end))
        if m(end)<0
            m(end)=-1e6;
        else
            m(end)=1e6;
        end
    end
end
m=m(:);
c=edge(pixel_no,1)-m.*edge(pixel_no,2);
end